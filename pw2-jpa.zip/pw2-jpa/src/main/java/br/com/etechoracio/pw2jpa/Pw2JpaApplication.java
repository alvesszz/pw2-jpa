package br.com.etechoracio.pw2jpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.com.etechoracio.pw2jpa.repository.UsuarioRepository;

@SpringBootApplication
public class Pw2JpaApplication implements CommandLineRunner {
	
	public static void main(String[] args) {
		SpringApplication.run(Pw2JpaApplication.class, args);
		
	}	
		
	@Autowired
	private UsuarioRepository usuarioRepository;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	} 
		
	}

