package br.com.etechoracio.jpa.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table (name = "TBL_USUARIO")

public class Usuario {
	
	@ManyToMany
	@Id
	@Column (name = ("ID_USUARIO"))
	@GeneratedValue (strategy =GenerationType.IDENTITY)
	private Long Id;
	
	@Column ( name = ("TX_NOME"))
	private String nome;
	
	@Column (name = ("TX_SENHA"))
	private String senha;
	
	@Column ( name = ("TP_DATANATIVAÇÃO"))
	private int datanativação;
	
	private List<GrupoUsuario> grupos;
	
	
}
