package br.com.etechoracio.pw2jpa.enums;

public enum StatusAgenteEnum {

	ATIVO,
	INATIVO,
	AFASTADO;
}
