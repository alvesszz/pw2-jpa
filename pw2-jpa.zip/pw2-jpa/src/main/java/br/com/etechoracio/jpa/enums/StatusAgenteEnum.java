package br.com.etechoracio.jpa.enums;

public enum StatusAgenteEnum {

	ATIVO,
	INATIVO,
	AFASTADO;
}
