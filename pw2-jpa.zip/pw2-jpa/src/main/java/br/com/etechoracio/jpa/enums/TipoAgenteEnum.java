package br.com.etechoracio.jpa.enums;

public enum TipoAgenteEnum {

	TRANSITO, 
	POLICIAL;
}
