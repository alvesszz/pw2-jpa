package br.com.etechoracio.pw2jpa.enums;

public enum TipoAgenteEnum {

	TRANSITO, 
	POLICIAL;
}
