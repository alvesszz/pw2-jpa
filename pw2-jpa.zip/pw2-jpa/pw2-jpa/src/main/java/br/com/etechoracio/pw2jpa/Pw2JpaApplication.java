package br.com.etechoracio.pw2jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw2JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw2JpaApplication.class, args);
	}

}
